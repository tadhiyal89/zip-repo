import { SingleDatePicker } from "react-dates";
import 'react-dates/initialize';
import 'react-dates/lib/css/_datepicker.css';
import './style/index.css';
function Calendar({
  date = null,
  onDateChange = () => {},
  focused,
  onFocusChange = () => {},
  id = "",
  placeholder=""
}) {
  return (
    <SingleDatePicker
      date={date}
      onDateChange={onDateChange}
      focused={focused}
      onFocusChange={onFocusChange}
      id={id}
      placeholder={placeholder}
    />
  );
}

export default Calendar;
