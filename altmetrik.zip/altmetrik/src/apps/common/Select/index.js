import ReactSelect from "react-select";
import './style/index.css';
const defaultName = "select-default";
const defaultDropDownID = "select-box";
function Select(props) {
  const {
    options = [],
    containerClassName = "",
    selectClassNamePrefix = "",
    isSearchable = true,
    name = defaultName,
    id = defaultDropDownID,
    placeholder="",
    required=false,
    onChange=()=>{},
    value
  } = props;
  return (
    <ReactSelect
      className={`select-box ${containerClassName}`}
      classNamePrefix={`select ${selectClassNamePrefix}`}
      isSearchable={isSearchable}
      name={name}
      options={options}
      id={id}
      placeholder={placeholder}
      required={required}
      onChange={onChange}
      value={value}
    />
  );
}

export default Select;
