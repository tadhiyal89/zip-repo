import React from "react";
import "./style/index.css";

/**
 *
 * @function Button
 * @export
 * @param {*} props
 * @returns it will return header html
 */
export default function Button(props) {
  const {
    id="",
    label = "",
    onClickCallBack = () => {},
    isDisabled = false,
    className = ""
  } = props;
  const dataProps = isDisabled ? { disabled: "disabled" } : {};
  return (
    <button
      id={id}
      onClick={onClickCallBack}
      className={`button ${className}`}
      {...dataProps}
    >
      {label}
    </button>
  );
}
