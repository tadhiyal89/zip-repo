import React, { useEffect } from "react";
import axios from "axios";
import InfiniteScroll from "react-infinite-scroll-component";
import getServiceApiConfig from "../../common/utils/applicationConfigCommon";
import Header from "../../common/Header";
import FilterSection from "../components/filterSection";
import FlightsFeedCard from "../components/flightCard";
import "./style/index.css";
import { buildUrl } from "../../common/utils/common";

/**
 *
 * @function Landing
 * @export
 * @returns This function will return the html for the landing page on the basis of conditioned
 */
export default function Landing() {
  const perPage = 2;
  const [pageIndex, setPageIndex] = React.useState(1);
  const [totalRecords, setTotalRecords] = React.useState(0);
  const [flightData, setFlightData] = React.useState([]);
  const [hasMore, setHasMore] = React.useState(true);
  const [locations, setLocations] = React.useState([]);
  const [optionalParams, setOptionalParams] = React.useState({});

  /**
   * @function handleFetchNextData
   * @summary this function is used to handleFetchNextData by incrementing the pageIndex 1
   * @param {*}
   * @return null
   */
  const handleFetchNextData = () => {
    setPageIndex(pageIndex + 1);
    getFlights();
  };

  /**
   * @variable loader
   * @summary this function returns loader html
   * @param {*}
   * @returns   loader html
   */
  const loader = <h4>Loading...</h4>;

  /**
   *@function noDataPresent
   *
   * @param {*}
   * @returns html containing no data present html
   */
  const noDataPresent = () => <h4>No data is present</h4>;

  /**
   *@function fetchData
   *
   * @param {*}
   * @returns null
   */
  const getFlights = () => {
    const { url } = getServiceApiConfig("getFlights");
    const params = {
      pageIndex,
      _limit: perPage,
      ...optionalParams
    };
    axios
      .get(buildUrl(url, params))
      .then(response => {
        const totalResults = 20;
        const { data } = response;
        const updateFlightDataArr = [...flightData, ...data];
        setTotalRecords(totalResults);
        setFlightData(updateFlightDataArr);
        setHasMore(updateFlightDataArr.length < totalResults);
      })
      .catch(err => {
        setTotalRecords(0);
        setFlightData([]);
        setHasMore(false);
      });
  };

  /**
   *@function fetchData
   *
   * @param {*}
   * @returns null
   */
  const getLocations = () => {
    const { url } = getServiceApiConfig("getLocations");
    axios
      .get(buildUrl(url))
      .then(response => {
        const { data } = response;
        setLocations(data);
      })
      .catch(err => {
        setTotalRecords(0);
      });
  };

  /**
   *@function handleOnSearchClick
   *
   * @param {*}
   * @returns null
   */
  const handleOnSearchClick = data => {
    const params = {
      fromId: data.sourceId,
      toId: data.destinationId,
      date: data.startDate
    };
    setFlightData([]);
    setTotalRecords(0);
    setOptionalParams(params);
    setTimeout(()=>{
    getFlights()},2000)
  };
  useEffect(getLocations, []);

  return (
    <div className="main-container">
      <Header title="Flight Search App" />
      <div id="scrollableDiv" className="container-body">
        <FilterSection
          sourceData={locations}
          destinationData={locations}
          handleOnSearchClickCallBack={handleOnSearchClick}
          required={true}
        />
        <div className="data-section">
          
          {flightData.length ? (
            <InfiniteScroll
              dataLength={flightData.length}
              next={handleFetchNextData}
              hasMore={hasMore}
              loader={loader}
              height={270}
            >
              {flightData.map(data => <FlightsFeedCard {...data} />)}
            </InfiniteScroll>
          ) : (
            noDataPresent()
          )}
        </div>
      </div>
    </div>
  );
}
