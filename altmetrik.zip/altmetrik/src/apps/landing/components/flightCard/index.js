import React from "react";
import { formatDate } from "../../../common/utils/common";
import "./style/index.css";

/**
 *
 * @function flightCard
 * @export
 * @param {*} props
 * @returns it will html of the card
 */
export default function flightCard(props) {
  const { from, to, time, flightName, flightNumber } = props;

  return (
    <div className="cards">
      <div className="card-info">
        <div className="initial-detail">
          <p className="card-intro">
            {from} - {to}
          </p>
          <h2 className="card-title">{flightName}</h2>
        </div>
        <div className="info-section">
          <span className="flight-number">{flightNumber}</span>
          <span className="time-section">
            {time ? formatDate(new Date(time), "dd-MM-yyyy h:mm:ss") : ""}
          </span>
        </div>
      </div>
    </div>
  );
}
