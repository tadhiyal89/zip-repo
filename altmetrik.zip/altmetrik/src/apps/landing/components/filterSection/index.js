import React, { useState,useEffect } from "react";
import Select from '../../../common/Select/index';
import Calendar from "../../../common/Calendar";
import Button from "../../../common/Button";
import "./style/index.css";
import moment from 'moment';

/**
 * @function filterSelection
 * @export
 * @param {*} props
 * @returns it will return searchInput box
 */
export default function FilterSelection(props) {
  const {sourceData:_sourceData,destinationData:_destinationData,handleOnSearchClickCallBack=()=>{}} = props;
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [startDateFocus, setStartDateFocus] = useState(false);
  const [endDateFocus, setEndDateFocus] = useState(false);
  const [sourceData, setSourceData] = useState(_sourceData);
  const [destinationData, setDestinationData] = useState(_destinationData);
  const [selectedSourceData, setSelectedSourceData] = useState(null);
  const [selectedDestinationData, setSelectedDestinationData] = useState(null);
  const minDate = moment().toDate()
  const handleStartDateChange = date => {
    setStartDate(date);
  };
  const handleEndDateChange = date => {
    setEndDate(date);
  };
  const handleStartDateFocusChange = focused => {
    setStartDateFocus(focused.focused);
  };
  const handleEndDateFocusChange = focused => {
    setEndDateFocus(focused.focused);
  };

  const handleOnSearchClick = ()=>{
    handleOnSearchClickCallBack({
      startDate:startDate?moment(startDate).format('YYYY-MM-DD'):null,
      endDate:endDate?moment(endDate).format('YYYY-MM-DD'):null,
      sourceId:selectedSourceData.value,
      destinationId: selectedDestinationData.value?selectedDestinationData.value:''
    });
  }

  const handleOnSourceChange = (value)=>{
    setSelectedSourceData(value);
  }
  const handleOnDestinationChange = (value)=>{
    setSelectedDestinationData(value);
  }
  useEffect(()=>{
    setSourceData(_sourceData);
  },[_sourceData]);
  useEffect(()=>{
    setDestinationData(_destinationData);
  },[_destinationData]);

  return (
    <div className="filter-section">
      <Select
          isSearchable={true}
          name="from"
          options={sourceData}
          placeholder="Select Source"
          id={"from-drop-down"}
          minDate={minDate}
          required={true}
          onChange={handleOnSourceChange}
          value={selectedSourceData}
        />
      <Select
          isSearchable={true}
          name="to"
          options={destinationData}
          placeholder="Select Destination"
          id={"to-drop-down"}
          minDate={minDate} 
          required={true}
          onChange={handleOnDestinationChange}
      />
      <Calendar
        id="from-date"
        date={startDate}
        focused={startDateFocus}
        onDateChange={handleStartDateChange}
        onFocusChange={handleStartDateFocusChange}
        placeholder={"Departure"}
        required={true}
      />
      <Calendar
        id="to-date"
        date={endDate}
        focused={endDateFocus}
        onDateChange={handleEndDateChange}
        onFocusChange={handleEndDateFocusChange}
        placeholder={"Return"}
      />
      <Button
        onClickCallBack={handleOnSearchClick}
        label={"Search"}
        isDisabled={!(selectedSourceData && selectedDestinationData && startDate)}
      />
    </div>
  );
}
