const baseURL = 'http://localhost';
const port = 3004;
const apiURL = `${baseURL}:${port}`
const config = {
  getLocations: {
    url: `${apiURL}/getLocations`
  },
  getFlights: {
    url: `${apiURL}/getFlights`
  }
};

export default config;
