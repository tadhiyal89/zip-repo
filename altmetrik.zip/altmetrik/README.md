# PROJECT CNID-CLIENT

## About

This is client side of the project where we are using react library to render the UI.


---

## Installation
After installing the NODE/NPM we need to run npm install or yarn install to install the dependencies
To run the JSON-SERVER we need to run yarn start:mock command 
#### Steps

    $ cd PROJECT/client
    $ npm install


## Start & watch

    $ npm start

## Simple build for production

    $ npm run build

## Languages & tools

### HTML

- [JSX for some templating.

### JavaScript

- [React](http://facebook.github.io/react) is used for UI.

### CSS

- [css3] is used to write futureproof CSS.